<?php

return [
    'vendor' => 'Ultimate Fosters',
    'vendor_url' => 'http://ultimatefosters.com',
    'email' => 'thewebfosters@gmail.com',
    'app_version' => "0.10",
    'lic1' => 'aHR0cHM6Ly9sLnVsdGltYXRlZm9zdGVycy5jb20vYXBpL3R5cGVfMQ==',
    'pid' => 2,
];
