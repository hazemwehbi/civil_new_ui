<?php

return [
    'en' => [
        'display' => 'English',
        'flag-icon' => 'us'
    ],
    'ar' => [
        'display' => 'Arabic',
        'flag-icon' => 'sa'
    ],
];