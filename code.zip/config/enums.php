<?php

return [
    'visit_request_status' => [
        'new' => "new",
        'accepted' => "accepted",
        'pending'=>"pending"
    ],
    // 'request_type' => [
    //     'visit_request' => __('data.visit_request'),
    //     'design_request' => __('data.design_request'),
    //     'support_service_request'=>__('data.support_service_request'),
    //     'contractor_request'=>__('data.contractor_request'),
    //     'supervision_request'=>__('data.supervision_request')
    // ]
    'user_types' => [
        'ESTATE_OWNER' => "Estate Owner",
        'ENGINEERING_OFFICE' => "Engineering Office",
        'SUPPORT_SERVICES_OFFICE' => "Support Service Office",
        
        'CONTRACTING_COMPANY' => "Contracting  Company",
        'GOVERNMENT_AGENCIES' => "Government Agencies",
        'SITE_MANAGENMENT' => "Site Managnment",

    ]
   
];